<div class="availability-area bg-white-smoke">
        <div class="container">
         
            <div class="row">
                <div class="col-md-12">
                    <form action="#" method="POST" class="advance_search_query">
                        <div class="form-content">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" name="firstname" placeholder="Firstname" value="<?= $edit_info->firstname;?>">
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label>Type</label>
                                <select>
                                   <option value="volvo">Apartments</option>
                                   <option value="saab">Saab</option>
                                   <option value="mercedes">Mercedes</option>
                                   <option value="audi">Audi</option>
                                </select>
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label>Price</label>
                                <input type="text" name="FirstName" placeholder="min">
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label>Range</label>
                                <input type="text" name="FirstName" placeholder="max">
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label>No of Seat</label>
                                <select>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                                </select>
                            </div><!-- /.form-group -->
                        </div><!-- /.form-content -->
                        <div class="form-content">
                            <div class="form-group">
                                <label>KEYWORDS</label>
                                <input type="text" name="FirstName" placeholder="Search for keywords">
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label>BED</label>
                                <select>
                                   <option value="1">1</option>
                                   <option value="2">2</option>
                                   <option value="3">3</option>
                                   <option value="4">4</option>
                                </select>
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label>Area(SQFT)</label>
                                <input type="text" name="FirstName" placeholder="min">
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label>Max</label>
                                <input type="text" name="FirstName" placeholder="max">
                            </div><!-- /.form-group -->
                            <div class="form-group">
                                <label>Floor Number</label>
                                <select>
                                  <option value="1">1</option>
                                  <option value="2">2</option>
                                  <option value="3">3</option>
                                  <option value="4">4</option>
                                  <option value="5">5</option>
                                  <option value="6">6</option>
                                  <option value="7">7</option>
                                  <option value="8">8</option>
                                  <option value="9">9</option>
                                  <option value="10">10</option>
                                </select>
                            </div><!-- /.form-group -->
                        </div><!-- /.form-content -->
                        <button type="submit" class=" button nevy-button">Update</button>
                    </form> <!-- /.advance_search_query -->
                </div><!-- /.col-md-12 -->
            </div><!-- /.row -->
        </div><!-- /.container  -->
    </div>