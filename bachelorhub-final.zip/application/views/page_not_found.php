<!-- ====== Error Page Area ====== --> 
	<div class="error-page-area">
		<div class="container-fluid pd-zero">
			<div class="default-template-gradient default-pd-center">
				<div class="row">
					<div class="col-md-12">
						<div class="error-text-content">
							<h2 class="error-title">404</h2>
							<p class="error-description">Page not pound</p>
							<a href="<?php echo base_url()?>" class="button nevy-blue-bg">go home</a>
						</div><!-- /.text-content -->
					</div><!-- /.col-md-12 -->
				</div><!-- /.row -->
			</div><!-- /.main-slider-->
		</div><!-- /.container-fluid -->           
	</div><!-- /.error-page-area -->