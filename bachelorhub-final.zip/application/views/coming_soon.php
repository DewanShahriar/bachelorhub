<!-- ====== Coming Soon ======= --> 
	<div class="commingsoon">
		<div class="container-fluid pd-zero">
			<div class="commingsoon-content jarallax" data-jarallax='{"speed": 0.3, "imgSrc": "assets/images/comming-soon-slider.jpg" }'>
				<div class="row gradient-transparent">
					<div class="col-md-6 full-width-content text-center">
						<h2 class="comming-heading">comming soon</h2>
						<h5 class="comming-description">We are working on something awesome!</h5>
						<div class="commingsoon-count" data-year="2018" data-month="6" data-day="5" data-hour="12" data-minutes="15"></div><!-- /.defaultCountdown -->
						<div class="social-link">
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-google-plus"></i></a>
                        </div>
					</div><!-- /.text-content -->
				</div><!-- /.col-md-12 -->
			</div><!-- /.row -->
		</div><!-- /.container-fluid -->           
	</div><!-- /.slider-area -->